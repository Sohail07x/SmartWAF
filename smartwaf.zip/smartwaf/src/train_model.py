"""
train_model.py
---------------
This script trains a machine learning model to detect malicious HTTP
requests (SQL Injection / XSS) vs benign ones.

Steps (beginner explanation):
1. Load the CSV dataset (data/requests.csv).
2. Turn each row into numeric features using extract_features().
3. Split the data into a training set (used to teach the model) and a
   test set (used to check how well it learned, on unseen data).
4. Train a RandomForestClassifier - a model made of many decision trees
   that vote together. It's a good beginner-friendly choice because it
   works well without much tuning.
5. Print accuracy/precision/recall/F1 so we know how good the model is.
6. Save the trained model to disk so other scripts (the API, the proxy)
   can load it without retraining every time.

Run with:
    python src/train_model.py
"""

import os
import csv
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

# Import our own feature extractor (see feature_extractor.py)
from feature_extractor import extract_features

# ---- File paths ----
# os.path.dirname(__file__) = the folder this script lives in (src/)
# We go "up one level" (..) to reach the project root, then into data/ or models/.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "..", "data", "requests.csv")
MODEL_PATH = os.path.join(BASE_DIR, "..", "models", "waf_model.joblib")


def load_dataset(csv_path):
    """Read the CSV file and return two lists: X (features) and y (labels)."""
    X = []
    y = []
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            url = row["url"]
            params = row["params"]
            label = int(row["label"])  # 0 = benign, 1 = malicious

            features = extract_features(url, params)
            X.append(features)
            y.append(label)
    return X, y


def main():
    print(f"Loading dataset from: {DATA_PATH}")
    X, y = load_dataset(DATA_PATH)
    print(f"Loaded {len(X)} rows.")

    # Split into 80% training data, 20% testing data.
    # random_state=42 just makes the split repeatable every time you run it.
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # Create the model. n_estimators=100 means "build 100 decision trees".
    model = RandomForestClassifier(n_estimators=100, random_state=42)

    # Train (fit) the model on the training data.
    print("Training model...")
    model.fit(X_train, y_train)

    # Test the model on data it has NEVER seen before.
    y_pred = model.predict(X_test)

    # Calculate how good the model is.
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, zero_division=0)
    recall = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)

    print("\n--- Evaluation on Test Set ---")
    print(f"Accuracy : {accuracy:.2f}")
    print(f"Precision: {precision:.2f}")
    print(f"Recall   : {recall:.2f}")
    print(f"F1 Score : {f1:.2f}")

    # Save the trained model to disk.
    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    print(f"\nModel saved to: {MODEL_PATH}")


if __name__ == "__main__":
    main()
