"""
dashboard.py
------------
Provides the /dashboard route, which reads logs/requests.log and shows
a simple HTML table of recent requests (allowed vs blocked).

This file does NOT run its own Flask server. Instead, it defines a
function `register_dashboard(app)` that adds the /dashboard route onto
an existing Flask app (waf_proxy.py calls this). This keeps everything
on one port (5000) so you only need to run one server for the full demo.
"""

import os
from flask import render_template

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_PATH = os.path.join(BASE_DIR, "..", "logs", "requests.log")


def parse_log_file(log_path):
    """
    Read logs/requests.log and turn each line into a dictionary.

    Each log line looks like:
        2026-07-23 10:15:00 | url=/login | params=username=admin | label=attack | score=0.95
    """
    requests_list = []

    if not os.path.exists(log_path):
        return requests_list

    with open(log_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            # Split the line into its "time | url=.. | params=.. | label=.. | score=.." parts
            parts = line.split(" | ")
            if len(parts) != 5:
                continue  # skip malformed lines

            time_str = parts[0]
            url = parts[1].replace("url=", "", 1)
            params = parts[2].replace("params=", "", 1)
            label = parts[3].replace("label=", "", 1)
            score = parts[4].replace("score=", "", 1)

            requests_list.append({
                "time": time_str,
                "url": url,
                "params": params,
                "label": label,
                "score": score,
            })

    # Show most recent requests first.
    requests_list.reverse()
    return requests_list


def register_dashboard(app):
    """Attach the /dashboard route to an existing Flask app."""

    @app.route("/dashboard")
    def dashboard():
        requests_list = parse_log_file(LOG_PATH)
        return render_template("dashboard.html", requests=requests_list)

    return app
