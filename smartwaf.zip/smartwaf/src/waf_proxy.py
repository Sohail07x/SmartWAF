"""
waf_proxy.py
------------
This simulates a "protected" web application sitting behind SmartWAF.

Route:
    GET /waf?url=...&params=...
    (in a real WAF, url/params would come from the actual incoming request;
     here we accept them as query parameters so you can test easily from
     a browser address bar)

For every request it:
    1. Extracts url + params.
    2. Classifies it using the same logic as classifier_service.py
       (called directly as a Python function, not over HTTP, to keep
       this demo simple and fast).
    3. Shows "Request allowed" or "Blocked by SmartWAF".
    4. Logs the event to logs/requests.log.

Run with:
    python src/waf_proxy.py

Then visit in your browser, e.g.:
    http://127.0.0.1:5000/waf?url=/home&params=
    http://127.0.0.1:5000/waf?url=/login&params=username=admin' OR '1'='1
"""

import os
import datetime
from flask import Flask, request, Response

from classifier_service import classify_request
from dashboard import register_dashboard

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_PATH = os.path.join(BASE_DIR, "..", "logs", "requests.log")
TEMPLATE_DIR = os.path.join(BASE_DIR, "..", "templates")
STATIC_DIR = os.path.join(BASE_DIR, "..", "static")

app = Flask(__name__, template_folder=TEMPLATE_DIR, static_folder=STATIC_DIR)

# Adds the /dashboard route onto this same app (see dashboard.py)
register_dashboard(app)

ALLOWED_PAGE = """
<html>
  <body style="font-family: sans-serif; text-align:center; margin-top: 80px;">
    <h1 style="color: green;">✅ Request Allowed</h1>
    <p>Your request looked safe, so SmartWAF let it through.</p>
    <p><a href="/dashboard">View Dashboard</a></p>
  </body>
</html>
"""

BLOCKED_PAGE = """
<html>
  <body style="font-family: sans-serif; text-align:center; margin-top: 80px;">
    <h1 style="color: red;">🚫 Blocked by SmartWAF</h1>
    <p>This request looked malicious (SQL Injection / XSS pattern detected).</p>
    <p><a href="/dashboard">View Dashboard</a></p>
  </body>
</html>
"""


def log_event(url: str, params: str, label: str, score: float = None):
    """Append one line describing this request to logs/requests.log."""
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    score_text = f"{score:.2f}" if score is not None else "-"
    line = f"{timestamp} | url={url} | params={params} | label={label} | score={score_text}\n"
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(line)


@app.route("/waf")
def waf_endpoint():
    # In this demo, url/params are passed as query string args so you can
    # trigger them straight from a browser address bar.
    url = request.args.get("url", "/")
    params = request.args.get("params", "")

    label, score = classify_request(url, params)
    log_event(url, params, label, score)

    if label == "attack":
        return Response(BLOCKED_PAGE, mimetype="text/html")
    else:
        return Response(ALLOWED_PAGE, mimetype="text/html")


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
