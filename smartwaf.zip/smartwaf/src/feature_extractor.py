"""
feature_extractor.py
---------------------
This file turns a raw HTTP request (url + params) into a list of numbers
(called "features") that a machine learning model can understand.

Think of it like this: the ML model cannot read text directly, so we
count/measure specific things in the request that are known to be
suspicious in SQL Injection (SQLi) and Cross-Site Scripting (XSS) attacks.
"""

from typing import List

# A short list of SQL keywords that commonly appear in SQL Injection attacks.
# We check the combined text (url + params) for these words.
SQL_KEYWORDS = [
    "select", "union", "drop", "insert", "delete", "update",
    "or 1=1", "' or '", "sleep(", "--", ";--"
]


def extract_features(url: str, params: str) -> List[float]:
    """
    Convert a URL and its parameters into a fixed-length list of numeric
    features.

    Parameters
    ----------
    url : str
        The path part of the request, e.g. "/login"
    params : str
        The query string / form data, e.g. "username=admin' OR '1'='1"

    Returns
    -------
    List[float]
        A list of 6 numbers describing the request.
    """

    # Combine url + params into one string so we only have to scan once.
    # We also lowercase everything so "SELECT" and "select" are treated
    # the same way.
    text = f"{url} {params}".lower()

    # ---- Feature 1: Length of the URL ----
    # Attackers sometimes use very long URLs to hide payloads or to try
    # buffer-overflow-style tricks. A benign URL like "/home" is short.
    url_length = len(url)

    # ---- Feature 2: Length of the params string ----
    # SQLi/XSS payloads tend to make the params string longer than a
    # normal "username=alice" style value.
    params_length = len(params)

    # ---- Feature 3: Count of single quotes (') ----
    # Single quotes are the classic character used to "break out" of a
    # SQL string, e.g.  admin' OR '1'='1
    quote_count = text.count("'")

    # ---- Feature 4: Count of angle brackets (< and >) ----
    # Angle brackets are used to inject HTML/JS tags for XSS,
    # e.g. <script>alert(1)</script>
    angle_bracket_count = text.count("<") + text.count(">")

    # ---- Feature 5: Presence of SQL keywords (0 or 1) ----
    # If any known SQL keyword appears anywhere in the text, this is 1,
    # otherwise 0. This is a simple "keyword spotting" feature.
    has_sql_keyword = 1.0 if any(keyword in text for keyword in SQL_KEYWORDS) else 0.0

    # ---- Feature 6: Presence of <script> tag (0 or 1) ----
    # A very strong signal for XSS attacks specifically.
    has_script_tag = 1.0 if "<script" in text else 0.0

    features = [
        float(url_length),
        float(params_length),
        float(quote_count),
        float(angle_bracket_count),
        has_sql_keyword,
        has_script_tag,
    ]

    return features


# Human-readable names for the features above, in the same order.
# Useful for printing feature importance later.
FEATURE_NAMES = [
    "url_length",
    "params_length",
    "quote_count",
    "angle_bracket_count",
    "has_sql_keyword",
    "has_script_tag",
]


if __name__ == "__main__":
    # Quick manual test you can run with: python src/feature_extractor.py
    examples = [
        ("/home", ""),
        ("/login", "username=admin' OR '1'='1"),
        ("/comment", "text=<script>alert(1)</script>"),
    ]
    for url, params in examples:
        feats = extract_features(url, params)
        print(f"url={url!r} params={params!r} -> {feats}")
