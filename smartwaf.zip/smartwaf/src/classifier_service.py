"""
classifier_service.py
----------------------
A small Flask API that loads the trained model and exposes one endpoint:

    POST /classify
    body: { "url": "...", "params": "..." }
    response: { "label": "benign" }
           or { "label": "attack", "score": 0.95 }

Run with:
    python src/classifier_service.py

Test with curl:
    curl -X POST http://127.0.0.1:5001/classify \
         -H "Content-Type: application/json" \
         -d "{\"url\": \"/login\", \"params\": \"username=admin' OR '1'='1\"}"
"""

import os
import joblib
from flask import Flask, request, jsonify

from feature_extractor import extract_features

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "..", "models", "waf_model.joblib")

app = Flask(__name__)

# Load the trained model once, when the server starts (not on every request).
print(f"Loading model from: {MODEL_PATH}")
model = joblib.load(MODEL_PATH)


def classify_request(url: str, params: str):
    """
    Shared classification logic, reused by both the API and the WAF proxy.
    Returns a tuple: (label_str, score_float)
    """
    features = extract_features(url, params)

    # model.predict expects a list of rows, so we wrap our single row in [ ].
    prediction = model.predict([features])[0]  # 0 = benign, 1 = attack

    # predict_proba gives the model's confidence for each class.
    # [:, 1] would be the probability of class "1" (attack).
    probabilities = model.predict_proba([features])[0]
    attack_score = probabilities[1]  # confidence that this is an attack

    label = "attack" if prediction == 1 else "benign"
    return label, float(attack_score)


@app.route("/classify", methods=["POST"])
def classify():
    data = request.get_json(force=True, silent=True) or {}
    url = data.get("url", "")
    params = data.get("params", "")

    label, score = classify_request(url, params)

    if label == "attack":
        return jsonify({"label": "attack", "score": round(score, 2)})
    else:
        return jsonify({"label": "benign"})


if __name__ == "__main__":
    # Runs on port 5001 so it doesn't clash with waf_proxy.py (port 5000).
    app.run(host="127.0.0.1", port=5001, debug=True)
