# SmartWAF — ML-Based Web Application Firewall (Demo)

A beginner-friendly prototype of an intelligent Web Application Firewall
that uses a machine learning model to detect SQL Injection (SQLi) and
Cross-Site Scripting (XSS) attacks in HTTP requests, with a live
dashboard.

## 1. Project Structure

```
smartwaf/
├── data/
│   └── requests.csv          # Training dataset (benign + attack requests)
├── models/
│   └── waf_model.joblib      # Saved trained model (created after training)
├── src/
│   ├── feature_extractor.py  # Turns a request into numeric features
│   ├── train_model.py        # Trains and saves the ML model
│   ├── classifier_service.py # Flask API: POST /classify
│   ├── waf_proxy.py          # Flask app: /waf (allow/block) + /dashboard
│   └── dashboard.py          # Dashboard route logic (reads logs)
├── logs/
│   └── requests.log          # Created automatically as you send requests
├── templates/
│   └── dashboard.html        # Dashboard HTML page
├── static/
│   └── style.css             # Dashboard styling
└── requirements.txt
```

**File-by-file, one sentence each:**
- `data/requests.csv` — Labeled example HTTP requests (0 = benign, 1 = malicious) used to train the model.
- `models/waf_model.joblib` — The trained RandomForest model saved to disk so it doesn't need retraining every run.
- `src/feature_extractor.py` — Converts a `url` + `params` pair into 6 numeric features (lengths, quote counts, keyword flags).
- `src/train_model.py` — Loads the CSV, extracts features, trains a RandomForestClassifier, prints metrics, and saves the model.
- `src/classifier_service.py` — A Flask API exposing `POST /classify` for classifying a single request as benign/attack.
- `src/waf_proxy.py` — A Flask app simulating a protected endpoint (`/waf`) that allows or blocks requests and logs every decision; also hosts `/dashboard`.
- `src/dashboard.py` — Reads `logs/requests.log` and renders it as an HTML table (attack rows highlighted in red).
- `templates/dashboard.html` — The HTML template for the dashboard table.
- `static/style.css` — Basic styling, including the red/green row highlighting.

## 2. Setup

```bash
cd smartwaf
pip install -r requirements.txt
```

(`requirements.txt` contains: `flask`, `scikit-learn`, `joblib`)

## 3. Dataset

`data/requests.csv` has three columns: `url`, `params`, `label`.

- **Benign examples (label 0):** normal pages like `/home`, `/products?id=42`,
  `/login?username=alice&password=hunter2`.
- **Malicious examples (label 1):** SQLi payloads like
  `username=admin' OR '1'='1` or `id=1; DROP TABLE users;`, and XSS payloads
  like `text=<script>alert('xss')</script>`.

**To expand the dataset later:** add more rows following the same format.
For real-world realism, collect actual access logs (with permission),
or use public SQLi/XSS payload lists to generate more attack examples,
and normal traffic samples for more benign examples. More data
generally improves accuracy — the current CSV is intentionally small
for a fast classroom demo.

> ⚠️ Note: if a payload contains a comma, wrap the whole `params` value
> in double quotes in the CSV (e.g. `"q=' UNION SELECT a,b--"`), otherwise
> the comma will be misread as a new column.

## 4. Train the Model

```bash
python src/train_model.py
```

This prints Accuracy / Precision / Recall / F1 on a held-out test split,
and saves `models/waf_model.joblib`.

## 5. Run the Classifier API

```bash
python src/classifier_service.py
```

Runs on `http://127.0.0.1:5001`. Test it:

```bash
curl -X POST http://127.0.0.1:5001/classify \
  -H "Content-Type: application/json" \
  -d "{\"url\": \"/login\", \"params\": \"username=admin' OR '1'='1\"}"
```

Expected response: `{"label": "attack", "score": 0.95}` (score will vary
slightly depending on training).

## 6. Run the WAF Proxy + Dashboard

```bash
python src/waf_proxy.py
```

Runs on `http://127.0.0.1:5000` and includes both `/waf` and `/dashboard`.

## 7. Step-by-Step Testing Plan

1. `python src/train_model.py` — train once, confirm metrics print and
   `models/waf_model.joblib` is created.
2. `python src/waf_proxy.py` — start the combined proxy + dashboard server.
   (`classifier_service.py` can be run separately too, on its own port,
   if you want to test the raw API independently.)
3. Visit a **benign** URL in your browser:
   `http://127.0.0.1:5000/waf?url=/home&params=`
   → should show "✅ Request Allowed".
4. Visit a **SQL Injection** URL:
   `http://127.0.0.1:5000/waf?url=/login&params=username=admin' OR '1'='1`
   → should show "🚫 Blocked by SmartWAF".
5. Visit an **XSS** URL:
   `http://127.0.0.1:5000/waf?url=/comment&params=text=<script>alert(1)</script>`
   → should show "🚫 Blocked by SmartWAF".
6. Visit another benign example:
   `http://127.0.0.1:5000/waf?url=/products&params=id=42`
   → should show "✅ Request Allowed".
7. Open `http://127.0.0.1:5000/dashboard` and confirm all four requests
   above appear in the table, with the two attacks highlighted in red.

## 8. Mapping to an IEEE-Style B.Tech Report

| Report Section | Where it comes from |
|---|---|
| Methodology / Feature Engineering | `data/requests.csv` + `src/feature_extractor.py` (the 6 chosen features and why they matter) |
| Proposed Methodology | Choice of RandomForestClassifier, train/test split logic in `src/train_model.py` |
| Experimental Results | Accuracy / Precision / Recall / F1 printed by `src/train_model.py` |
| System Implementation | `src/classifier_service.py` (API) and `src/waf_proxy.py` (proxy allow/block logic) |
| System Implementation + Discussion | `src/dashboard.py` + `templates/dashboard.html` — live monitoring of allowed vs blocked requests, and `logs/requests.log` as the audit trail |
| Conclusion | Summarize the metrics from step 4 and observed allow/block behavior from step 7's manual tests |

## Notes / Limitations (good to mention in your report's "Future Work")

- This is a demo classifier using simple hand-crafted features, not a
  production-grade WAF — real systems combine ML with rule-based
  signatures and continuous retraining on live traffic.
- The dataset is intentionally small; a larger, more diverse dataset
  would improve generalization and reduce false positives/negatives.
- The Flask dev server (`debug=True`) is for local development only —
  never use it as-is in production.
